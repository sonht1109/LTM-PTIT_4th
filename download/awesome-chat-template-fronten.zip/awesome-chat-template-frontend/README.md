# Awesome-Chat-Template-Frontend

Trong Template giao diện này có sử dụng những thư viện phía client với chính xác các phiên bản như sau:

- bootstrap: **^3.3.7**
- font-awesome **^4.7.0**
- jquery **^3.3.1**
- AlertifyJS **^1.11.0**
- jquery.nicescroll **^3.7.6**
- moment **^2.21.0**
- emojionearea **^3.0.0**
- peerjs **^0.3.14**
- sweetalert2 **^7.33.1**
- photoset-grid **^1.0.1**
- jquery-colorbox **^1.6.4**

Các bạn vui lòng làm theo hướng dẫn trong video của mình, sử dụng chính xác phiên bản của các thư viện này để tránh gặp những lỗi không đáng có nhé.
Thank you so much!

Author: Trung Quân

Blog: https://trungquandev.com/

CV: https://cv.trungquandev.com/

"A little bit of fragrance always clings to the hands that gives you roses!"
